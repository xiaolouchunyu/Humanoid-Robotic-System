#!/usr/bin/env python

####################################################################################
#This node should handle tracking the positions of NAO, all known objects and obstacles
#
#Subscribes to:
#detected markers
#detected obstacles
#robot movements
#
#Published to:
#object positions

from xmlrpc.server import DocXMLRPCRequestHandler
import rospy
import math
from std_msgs.msg import String
from aruco_position.msg import aruco_position
from nav_msgs.msg import Odometry

obstacle_id = 1
reference_ids = [1,2,3,4]
nao_initial_pos = [0,1]
dist_threshold = 0.2    #Distance in meters below which 2 detected entities are determined to be the same

class Map:
    def __init__(self):
        #Initialize the lists containing objects and obstacles
        self.obstacles = []
        self.objects = []

        #Define initial map of the room - all object delivery bays and reference aruco markers to identify nao's position
        #For simplicity, coordinates floow a [x,y,heigth] scheme
        self.redbay = [0,0,0]
        self.greenbay = [1,1,1]
        self.bluebay = [0,0,1]

        self.ref1 = [1,2]
        self.ref2 = [2,2]
        self.ref3 = [2,2]
        self.ref4 = [2,2]

        self.nao_pos = nao_initial_pos
        self.nao_orientation = 0      #NAO anti-clockwise rotation angle around the z direction in rad

    def add_object(self,x,y,z,color):
        #Based on the given coordinates, checks if detected object corresponds to an existing one. If not, adds it to the map
        match = 0
        for object in self.objects:
            dist = self.get_distance(object, [x,y])
            if dist<dist_threshold:
                match = 1
                break

        if match == 0:
            #Adds new obstacle to the map
            x = self.nao_pos[1] + math.sin(self.nao_orientation)*x
            y = self.nao_pos[2] + math.cos(self.nao_orientation)*y
            object = [x,y,z,color]
            self.objects.append(object)
            return
        else:
            #Obstacle already exists and does not need to be added to the map
            return

    def add_obstacle(self,x,y):
        #Based on the given coordinates, checks if detected object corresponds to an existing one. If not, adds it to the map
        match = 0
        for obstacle in self.obstacles:
            dist = self.get_distance(obstacle, [x,y])
            if dist<dist_threshold:
                match = 1
                break

        if match == 0:
            #Adds new obstacle to the map
            x = self.nao_pos[1] + math.sin(self.nao_orientation)*x
            y = self.nao_pos[2] + math.cos(self.nao_orientation)*y
            obstacle = [x,y]
            self.obstacles.append(obstacle)
            return
        else:
            #Obstacle already exists and does not need to be added to the map
            return


    remove_object()

    remove_obstacle()

    def aruco_pos_update(self,marker_x,marker_y,marker_z,id):
    #Sets NAO's map position based on reference aruco markers
        if id == 1:
            naox = self.ref1[1] - marker_x
            naoy = self.ref1[2] - marker_y
        elif id == 2:
            naox = self.ref2[1] - marker_x
            naoy = self.ref2[2] - marker_y
        elif id == 3:
            naox = self.ref3[1] - marker_x
            naoy = self.ref3[2] - marker_y
        elif id == 4:
            naox = self.ref4[1] - marker_x
            naoy = self.ref4[2] - marker_y

        self.nao_pos = [naox, naoy]
    
    def move_nao(self,x,y):
        naox = self.nao_pos[1] + x
        naoy = self.nao_pos[2] + y
        self.nao_pos = self.nao_pos

    def get_distance(entity1, entity2):
        dx = entity1[1] - entity2[1]
        dy = entity1[2] - entity2[2]
        dist = math.sqrt(dx**2 + dy**2)
        return dist


def object_callback(data):
    rospy.loginfo(rospy.get_caller_id() + "I heard %s", data.data)

def aruco_callback(odom):
    id = odom.child_frame_id
    x = odom.pose.pose.position.x
    y = odom.pose.pose.position.x
    z = odom.pose.pose.position.x

    #Detected marker is a reference marker
    if id in reference_ids:
        map.update_nao_pos(x,y,z,id)
    
    #Detected marker represents an obstacle
    elif id == obstacle_id:
        map.add_obstacle(x,y,z,id)

    else:
        print("Error, aruco ID does not match known markers")
    
def object_handler():
    rospy.init_node('listener', anonymous=True)

    rospy.Subscriber("object_handler", aruco_position, object_callback)
    rospy.Subscriber("aruco_handler", Odometry, aruco_callback)

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
    listener()